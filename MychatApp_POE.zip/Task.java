import java.util.ArrayList;
import java.util.List;

/**
 * Task class for QuickChat application - Part 3.
 * Handles task creation, searching, deletion, and reporting.
 */
public class Task {

    private String taskName;
    private int taskNumber;       // auto-incremented, zero-based
    private String taskDescription;
    private String developerDetails; // name of assigned developer
    private int taskDuration;     // hours
    private String taskStatus;    // "To Do", "Doing", "Done"
    private String taskID;        // generated: first 2 chars of taskName : taskNumber : last 2 chars of developerDetails

    private static List<Task> taskList = new ArrayList<>();
    private static int taskCounter = 0;

    public Task(String taskName, String taskDescription, String developerDetails,
                int taskDuration, String taskStatus) {
        this.taskName         = taskName;
        this.taskNumber       = taskCounter++;
        this.taskDescription  = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration     = taskDuration;
        this.taskStatus       = taskStatus;
        this.taskID           = createTaskID();
    }

    /**
     * Generates a Task ID in the format:
     * first 2 chars of taskName : taskNumber : last 2 chars of developerDetails
     * All uppercase, e.g. "TA:0:ER"
     */
    private String createTaskID() {
        String namePart = (taskName.length() >= 2 ? taskName.substring(0, 2) : taskName).toUpperCase();
        String devPart  = (developerDetails.length() >= 2
                ? developerDetails.substring(developerDetails.length() - 2)
                : developerDetails).toUpperCase();
        return namePart + ":" + taskNumber + ":" + devPart;
    }

    /**
     * Checks that the task description does not exceed 50 characters.
     * @return "Task successfully captured." or error message with character count
     */
    public String checkTaskDescription() {
        if (taskDescription == null) {
            return "Please enter a task description of less than 50 characters.";
        }
        if (taskDescription.length() <= 50) {
            return "Task successfully captured.";
        } else {
            return "Please enter a task description of less than 50 characters.";
        }
    }

    /**
     * Returns a formatted string with full task details.
     */
    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n"
             + "Developer Details: " + developerDetails + "\n"
             + "Task Number: " + taskNumber + "\n"
             + "Task Name: " + taskName + "\n"
             + "Task Description: " + taskDescription + "\n"
             + "Task ID: " + taskID + "\n"
             + "Duration: " + taskDuration + " hours";
    }

    // ==================== Static list management ====================

    /**
     * Adds this task to the shared task list.
     * @return "Task successfully added." always
     */
    public String addTask() {
        taskList.add(this);
        return "Task successfully added.";
    }

    /**
     * Returns the total duration (hours) across all tasks in the list.
     */
    public static int returnTotalHours() {
        int total = 0;
        for (Task t : taskList) {
            total += t.taskDuration;
        }
        return total;
    }

    /**
     * Searches for a task by its name (case-insensitive).
     * @return printTaskDetails() of the first match, or "Task not found."
     */
    public static String searchTaskByName(String name) {
        for (Task t : taskList) {
            if (t.taskName.equalsIgnoreCase(name)) {
                return t.printTaskDetails();
            }
        }
        return "Task not found.";
    }

    /**
     * Searches for all tasks assigned to a developer (case-insensitive).
     * @return concatenated printTaskDetails() of all matches, or "No tasks found for developer."
     */
    public static String searchTasksByDeveloper(String developer) {
        StringBuilder sb = new StringBuilder();
        for (Task t : taskList) {
            if (t.developerDetails.equalsIgnoreCase(developer)) {
                sb.append(t.printTaskDetails()).append("\n---\n");
            }
        }
        return sb.length() > 0 ? sb.toString().trim() : "No tasks found for developer.";
    }

    /**
     * Deletes a task from the list by task name (case-insensitive).
     * @return "Entry \"<taskName>\" successfully deleted." or "Task not found."
     */
    public static String deleteTask(String name) {
        for (int i = 0; i < taskList.size(); i++) {
            if (taskList.get(i).taskName.equalsIgnoreCase(name)) {
                String deleted = taskList.get(i).taskName;
                taskList.remove(i);
                return "Entry \"" + deleted + "\" successfully deleted.";
            }
        }
        return "Task not found.";
    }

    /**
     * Returns a summary report of all tasks: developer name, task name, and task status.
     * @return formatted report or "No tasks available." if list is empty
     */
    public static String displayReport() {
        if (taskList.isEmpty()) {
            return "No tasks available.";
        }
        StringBuilder sb = new StringBuilder();
        for (Task t : taskList) {
            sb.append("Developer: ").append(t.developerDetails)
              .append(", Task: ").append(t.taskName)
              .append(", Status: ").append(t.taskStatus)
              .append("\n");
        }
        return sb.toString().trim();
    }

    /**
     * Resets all static state. Used between unit tests.
     */
    public static void resetTasks() {
        taskList.clear();
        taskCounter = 0;
    }

    // ==================== Getters ====================

    public String getTaskName()         { return taskName; }
    public int    getTaskNumber()       { return taskNumber; }
    public String getTaskDescription()  { return taskDescription; }
    public String getDeveloperDetails() { return developerDetails; }
    public int    getTaskDuration()     { return taskDuration; }
    public String getTaskStatus()       { return taskStatus; }
    public String getTaskID()           { return taskID; }

    public static List<Task> getTaskList() { return taskList; }
}
