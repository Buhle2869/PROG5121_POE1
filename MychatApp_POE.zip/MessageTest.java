import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Message class — Parts 1, 2 & 3.
 *
 * Part 3 test data (from IIE PROG5121 assignment specification, pages 18-19):
 *   Message 1: Recipient +27834557896, "Did you get the cake?"                              — Sent
 *   Message 2: Recipient +27838884567, "Where are you? You are late! I have asked you to be on time." — Stored
 *   Message 3: Recipient +27834484567, "Yohoooo, I am at your gate."                       — Disregard
 *   Message 4: Recipient 0838884567,   "It is dinner time !"                               — Sent
 *   Message 5: Recipient +27838884567, "Ok, I am leaving without you."                     — Stored
 *
 * Required unit tests (rubric, page 19):
 *   1. Sent Messages array correctly populated
 *   2. Display the longest message
 *   3. Search for messageID
 *   4. Search all messages for a particular recipient
 *   5. Delete a message using message hash
 *   6. Display Report
 */
public class MessageTest {

    private Message msg1;
    private Message msg2;
    private Message msg3;
    private Message msg4;
    private Message msg5;

    @BeforeEach
    public void setUp() {
        Message.resetMessages();

        msg1 = new Message(0, "+27834557896", "Did you get the cake?");
        msg2 = new Message(1, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        msg3 = new Message(2, "+27834484567", "Yohoooo, I am at your gate.");
        msg4 = new Message(3, "0838884567",   "It is dinner time !");
        msg5 = new Message(4, "+27838884567", "Ok, I am leaving without you.");

        msg1.sentMessage(1); // Sent
        msg2.sentMessage(3); // Stored
        msg3.sentMessage(2); // Disregard
        msg4.sentMessage(1); // Sent
        msg5.sentMessage(3); // Stored

        Message.populateArrays();
    }

    // =====================================================================
    // Parts 1 & 2 tests — unchanged
    // =====================================================================

    @Test
    public void testMessageLengthUnder250() {
        Message m = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    public void testMessageLengthOver250() {
        String longMsg = "A".repeat(260);
        Message msg = new Message(0, "+27718693002", longMsg);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", msg.checkMessageLength());
    }

    @Test
    public void testRecipientCellCorrectlyFormatted() {
        Message m = new Message(0, "+27718693002", "Test");
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void testRecipientCellIncorrectlyFormatted() {
        Message m = new Message(0, "08575975889", "Test");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            m.checkRecipientCell()
        );
    }

    @Test
    public void testMessageHashCorrect() {
        Message m = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String hash = m.getMessageHash();
        assertTrue(hash.contains(":0:"), "Hash should contain ':0:'");
        assertTrue(hash.endsWith("HITONIGHT"), "Hash should end with HITONIGHT");
        assertEquals(hash.toUpperCase(), hash, "Hash should be all uppercase");
    }

    @Test
    public void testMessageHashesInLoop() {
        Message[] messages = {msg1, msg2};
        for (Message msg : messages) {
            String hash = msg.getMessageHash();
            assertNotNull(hash);
            assertFalse(hash.isEmpty());
            assertEquals(hash.toUpperCase(), hash);
            assertTrue(hash.contains(":"));
        }
    }

    @Test
    public void testSendMessage() {
        Message.resetMessages();
        Message m = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message successfully sent.", m.sentMessage(1));
    }

    @Test
    public void testDisregardMessage() {
        Message.resetMessages();
        Message m = new Message(0, "+27718693002", "Test message");
        assertEquals("Press 0 to delete the message.", m.sentMessage(2));
    }

    @Test
    public void testStoreMessage() {
        Message.resetMessages();
        Message m = new Message(0, "+27718693002", "Test message");
        assertEquals("Message successfully stored.", m.sentMessage(3));
    }

    @Test
    public void testMessageIDNotMoreThan10Characters() {
        assertTrue(msg1.checkMessageID(), "Message ID should be <= 10 characters");
    }

    @Test
    public void testMessageIDGenerated() {
        String id = msg1.getMessageID();
        assertNotNull(id);
        assertTrue(id.length() <= 10);
    }

    @Test
    public void testReturnTotalMessagesSent() {
        Message.resetMessages();
        Message m = new Message(0, "+27718693002", "Test");
        m.sentMessage(1);
        assertEquals(1, Message.returnTotalMessages());
    }

    // =====================================================================
    // Part 3 tests
    // =====================================================================

    // ----- 1. Sent Messages array correctly populated --------------------

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        // Spec: developer entry for messages 1-4; sent messages are msg1 and msg4
        String[] texts = Message.getSentMessageTexts();
        assertEquals(2, texts.length, "There should be 2 sent messages in the array");

        boolean foundMsg1 = false;
        boolean foundMsg4 = false;
        for (String t : texts) {
            if ("Did you get the cake?".equals(t)) foundMsg1 = true;
            if ("It is dinner time !".equals(t))   foundMsg4 = true;
        }
        assertTrue(foundMsg1, "Sent array must contain 'Did you get the cake?'");
        assertTrue(foundMsg4, "Sent array must contain 'It is dinner time !'");
    }

    @Test
    public void testSentMessageHashesArrayPopulated() {
        String[] hashes = Message.getSentMessageHashes();
        assertEquals(2, hashes.length);
        for (String h : hashes) {
            assertNotNull(h);
            assertFalse(h.isEmpty());
        }
    }

    @Test
    public void testSentRecipientsArrayPopulated() {
        String[] recipients = Message.getSentRecipients();
        assertEquals(2, recipients.length);
    }

    @Test
    public void testSentMessageIDsArrayPopulated() {
        String[] ids = Message.getSentMessageIDs();
        assertEquals(2, ids.length);
        for (String id : ids) {
            assertNotNull(id);
            assertTrue(id.length() <= 10);
        }
    }

    // ----- 2. Display the longest message --------------------------------

    @Test
    public void testGetLongestMessageFromSentArray() {
        // Among the two sent messages, msg1 "Did you get the cake?" (21 chars)
        // is longer than msg4 "It is dinner time !" (19 chars)
        String longest = Message.getLongestMessage();
        assertEquals("Did you get the cake?", longest,
                "Longest sent message should be 'Did you get the cake?'");
    }

    @Test
    public void testGetLongestMessageOverallMatchesSpec() {
        // Spec (page 19): with messages 1-4 loaded, system returns msg2
        // "Where are you? You are late! I have asked you to be on time."
        String longest = Message.getLongestMessageOverall();
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest,
            "Overall longest message across sent + stored must match spec"
        );
    }

    // ----- 3. Search for messageID ---------------------------------------

    @Test
    public void testSearchMessageByIDFound() {
        // msg4 is index 1 in the sent array (msg1=0, msg4=1)
        String msg4ID = Message.getSentMessageIDs()[1];
        String result = Message.searchMessageByID(msg4ID);
        assertTrue(result.contains("It is dinner time !"),
                "Search by ID should return msg4 text");
        assertTrue(result.contains("0838884567"),
                "Search by ID should return msg4 recipient");
    }

    @Test
    public void testSearchMessageByIDNotFound() {
        assertEquals("Message ID not found.", Message.searchMessageByID("9999999999"));
    }

    // ----- 4. Search all messages for a particular recipient -------------

    @Test
    public void testSearchMessagesByRecipientFound() {
        // Spec: recipient +27838884567 → returns msg2 AND msg5 texts
        String result = Message.searchMessagesByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."),
                "Should return msg2 for recipient +27838884567");
        assertTrue(result.contains("Ok, I am leaving without you."),
                "Should return msg5 for recipient +27838884567");
    }

    @Test
    public void testSearchMessagesByRecipientNotFound() {
        assertEquals("No messages found for recipient.",
                Message.searchMessagesByRecipient("+27999999999"));
    }

    // ----- 5. Delete a message using message hash ------------------------

    @Test
    public void testDeleteMessageByHashSuccessfully() {
        // Delete msg1 (index 0 of sent array) by its hash
        String hashToDelete = Message.getSentMessageHashes()[0];
        String result = Message.deleteMessageByHash(hashToDelete);
        assertTrue(result.contains("successfully deleted"),
                "Delete should confirm successful deletion");
        assertTrue(result.contains("Did you get the cake?"),
                "Delete confirmation should include the deleted message text");
    }

    @Test
    public void testDeleteMessageReducesArraySize() {
        int before = Message.getSentMessageTexts().length;
        String hashToDelete = Message.getSentMessageHashes()[0];
        Message.deleteMessageByHash(hashToDelete);
        int after = Message.getSentMessageTexts().length;
        assertEquals(before - 1, after,
                "Array size should decrease by 1 after deletion");
    }

    @Test
    public void testDeleteMessageByHashNotFound() {
        assertEquals("Hash not found.", Message.deleteMessageByHash("XX:99:FAKEHASH"));
    }

    @Test
    public void testDeletedMessageNoLongerReturnsInSearch() {
        String hashToDelete = Message.getSentMessageHashes()[0];
        String deletedID    = Message.getSentMessageIDs()[0];
        Message.deleteMessageByHash(hashToDelete);
        assertEquals("Message ID not found.", Message.searchMessageByID(deletedID),
                "Deleted message should not be found by ID after deletion");
    }

    // ----- 6. Display Report ---------------------------------------------

    @Test
    public void testDisplayReportContainsRequiredFields() {
        // Spec: report must show Message Hash, Recipient, and Message
        String report = Message.displayMessageReport();
        assertTrue(report.contains("Message Hash:"), "Report must include Message Hash label");
        assertTrue(report.contains("Recipient:"),    "Report must include Recipient label");
        assertTrue(report.contains("Message:"),      "Report must include Message label");
    }

    @Test
    public void testDisplayReportContainsSentMessageTexts() {
        String report = Message.displayMessageReport();
        assertTrue(report.contains("Did you get the cake?"),
                "Report must include msg1 text");
        assertTrue(report.contains("It is dinner time !"),
                "Report must include msg4 text");
    }

    @Test
    public void testDisplayReportWhenNoMessagesSent() {
        Message.resetMessages();
        assertEquals("No sent messages to display.", Message.displayMessageReport());
    }
}
