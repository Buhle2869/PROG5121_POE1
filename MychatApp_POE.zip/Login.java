/**
 * Login class for QuickChat application.
 * Handles user registration and authentication.
 *
 * Reference: Regex patterns adapted from:
 * https://www.regular-expressions.info/phone.html (international phone format)
 * https://owasp.org/www-community/password-special-characters (password complexity)
 */
public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    public Login(String firstName, String lastName, String username, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    /**
     * Checks that the username contains an underscore and is no more than 5 characters long.
     * @return true if valid, false otherwise
     */
    public boolean checkUserName() {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks password complexity rules:
     * - At least 8 characters
     * - Contains a capital letter
     * - Contains a number
     * - Contains a special character
     * @return true if all rules pass, false otherwise
     */
    public boolean checkPasswordComplexity() {
        if (password == null) return false;
        boolean hasLength  = password.length() >= 8;
        boolean hasUpper   = password.matches(".*[A-Z].*");
        boolean hasDigit   = password.matches(".*[0-9].*");
        boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");
        return hasLength && hasUpper && hasDigit && hasSpecial;
    }

    /**
     * Checks that the cell phone number starts with an international code ('+')
     * and the total number portion is no more than 10 digits.
     *
     * Regex reference: https://www.regular-expressions.info/phone.html
     * @return true if valid, false otherwise
     */
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        return cellPhoneNumber.matches("^\\+[0-9]{1,3}[0-9]{1,10}$");
    }

    /**
     * Registers the user and returns appropriate message for each validation step.
     * @return registration status message
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        return "Username successfully captured. Password successfully captured. Cell phone number successfully added.";
    }

    /**
     * Verifies login credentials against stored registration details.
     * @param enteredUsername the username entered at login
     * @param enteredPassword the password entered at login
     * @return true if credentials match, false otherwise
     */
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    /**
     * Returns a login status message.
     * @param enteredUsername the username entered at login
     * @param enteredPassword the password entered at login
     * @return welcome message on success, error message on failure
     */
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters
    public String getUsername()  { return username; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
}
