import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Message class for QuickChat application.
 * Parts 1 & 2: message creation, validation, sending, storing, and retrieval.
 * Part  3    : parallel arrays, JSON reading, longest message, search by
 *              recipient/messageID, delete by hash, and full report display.
 *
 * JSON storage research reference: https://github.com/fangyidong/json-simple
 * Note: storeMessageToJSON() uses manual JSON string construction —
 *       no external library required.
 */
public class Message {

    // ------------------------------------------------------------------ fields
    private String messageID;
    private int    messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private String status; // "Sent", "Stored", "Disregarded"

    // ------------------------------------------------------------------ static lists (Parts 1 & 2)
    private static List<Message> sentMessages       = new ArrayList<>();
    private static List<Message> storedMessages     = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;

    // ------------------------------------------------------------------ Part 3 parallel arrays
    // These are populated via populateArrays() after messages are added.
    private static String[] sentMessageHashes     = new String[0];
    private static String[] sentMessageIDs        = new String[0];
    private static String[] sentRecipients        = new String[0];
    private static String[] sentMessageTexts      = new String[0];

    // ================================================================== constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageID     = generateMessageID();
        this.messageHash   = createMessageHash();
    }

    // ================================================================== Part 1 & 2 methods

    /**
     * Generates a random 10-digit message ID.
     * @return 10-digit string ID
     */
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    /**
     * Checks that the message ID is not more than 10 characters.
     * @return true if valid, false otherwise
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /**
     * Checks that the recipient cell number contains an international code
     * and is the correct length.
     * @return message indicating success or failure
     */
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+[0-9]{1,3}[0-9]{1,10}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    /**
     * Creates the message hash in the format:
     * first two digits of messageID : messageNumber : firstWord + lastWord (all caps, no punctuation)
     * Example: 00:0:HITONIGHT
     * @return the message hash string
     */
    public String createMessageHash() {
        if (messageID == null || messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        String   idPrefix  = messageID.substring(0, Math.min(2, messageID.length()));
        String[] words     = messageText.trim().split("\\s+");
        String   firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String   lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        String   hash      = (idPrefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
        this.messageHash   = hash;
        return hash;
    }

    /**
     * Handles sending, storing, or disregarding a message based on user choice.
     * @param choice 1=Send, 2=Disregard, 3=Store
     * @return status message
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                this.status = "Sent";
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                this.status = "Disregarded";
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case 3:
                this.status = "Stored";
                storedMessages.add(this);
                // Note: JSON persistence is handled explicitly by the caller (QuickChat)
                // to avoid unintended disk I/O during unit tests.
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    /**
     * Validates message length (max 250 characters).
     * @return "Message ready to send." or error with overage count
     */
    public String checkMessageLength() {
        if (messageText == null) {
            return "Message exceeds 250 characters by 0; please reduce the size.";
        }
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = messageText.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
    }

    /**
     * Returns all sent messages with full details (ID, Hash, Recipient, Message).
     * @return formatted string of all sent messages
     */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
            sb.append("----------------------------\n");
        }
        return sb.toString();
    }

    /**
     * Returns the total number of messages sent.
     * @return count of sent messages
     */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ================================================================== Part 3 methods

    /**
     * Populates the five parallel arrays from the sentMessages list.
     * Must be called after messages are sent so the arrays reflect current state.
     * Reference: Array parallel structure as per IIE PROG5121 Part 3 specification.
     */
    public static void populateArrays() {
        int size = sentMessages.size();
        sentMessageHashes = new String[size];
        sentMessageIDs    = new String[size];
        sentRecipients    = new String[size];
        sentMessageTexts  = new String[size];

        for (int i = 0; i < size; i++) {
            Message m = sentMessages.get(i);
            sentMessageHashes[i] = m.messageHash;
            sentMessageIDs[i]    = m.messageID;
            sentRecipients[i]    = m.recipient;
            sentMessageTexts[i]  = m.messageText;
        }
    }

    /**
     * Finds and returns the longest message text from the sent messages array.
     * Searches the sentMessageTexts parallel array.
     * @return the longest message text, or "No messages available." if array is empty
     */
    public static String getLongestMessage() {
        if (sentMessageTexts.length == 0) {
            return "No messages available.";
        }
        String longest = sentMessageTexts[0];
        for (int i = 1; i < sentMessageTexts.length; i++) {
            if (sentMessageTexts[i] != null && sentMessageTexts[i].length() > longest.length()) {
                longest = sentMessageTexts[i];
            }
        }
        return longest;
    }

    /**
     * Finds the longest message text across ALL messages (sent + stored + disregarded).
     * Used to satisfy the spec requirement: "Display the longest message" from messages 1-4.
     * @return the longest message text overall, or "No messages available."
     */
    public static String getLongestMessageOverall() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        if (all.isEmpty()) {
            return "No messages available.";
        }
        String longest = all.get(0).messageText;
        for (Message m : all) {
            if (m.messageText != null && m.messageText.length() > longest.length()) {
                longest = m.messageText;
            }
        }
        return longest;
    }

    /**
     * Searches the sentMessageIDs parallel array for a given messageID and
     * returns the corresponding recipient and message text.
     * @param messageID the ID to search for
     * @return formatted recipient + message string, or "Message ID not found."
     */
    public static String searchMessageByID(String messageID) {
        for (int i = 0; i < sentMessageIDs.length; i++) {
            if (sentMessageIDs[i] != null && sentMessageIDs[i].equals(messageID)) {
                return "Recipient: " + sentRecipients[i] + "\nMessage: " + sentMessageTexts[i];
            }
        }
        return "Message ID not found.";
    }

    /**
     * Searches both sentMessages and storedMessages for all messages sent to
     * a given recipient (case-insensitive).
     * @param recipient the phone number to search for
     * @return all matching message texts joined by a space, or "No messages found for recipient."
     */
    public static String searchMessagesByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();

        // Search sent array
        for (int i = 0; i < sentRecipients.length; i++) {
            if (sentRecipients[i] != null && sentRecipients[i].equalsIgnoreCase(recipient)) {
                sb.append("\"").append(sentMessageTexts[i]).append("\" ");
            }
        }

        // Also search stored messages list
        for (Message m : storedMessages) {
            if (m.recipient != null && m.recipient.equalsIgnoreCase(recipient)) {
                sb.append("\"").append(m.messageText).append("\" ");
            }
        }

        return sb.length() > 0
                ? sb.toString().trim()
                : "No messages found for recipient.";
    }

    /**
     * Deletes a message from the sentMessages list and parallel arrays using its hash.
     * @param hash the message hash to delete
     * @return confirmation string including the deleted message text, or "Hash not found."
     */
    public static String deleteMessageByHash(String hash) {
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).messageHash.equalsIgnoreCase(hash)) {
                String deletedText = sentMessages.get(i).messageText;
                sentMessages.remove(i);
                totalMessagesSent = sentMessages.size();
                populateArrays(); // rebuild arrays after deletion
                return "Message: \"" + deletedText + "\" successfully deleted.";
            }
        }
        return "Hash not found.";
    }

    /**
     * Displays a full report of all sent messages, showing:
     * Message Hash, Recipient, and Message text for each.
     * @return formatted report string, or "No sent messages to display." if empty
     */
    public static String displayMessageReport() {
        if (sentMessages.isEmpty()) {
            return "No sent messages to display.";
        }
        // Defensively rebuild arrays in case populateArrays() was not called
        // after the last send — keeps arrays in sync with the sentMessages list.
        populateArrays();
        StringBuilder sb = new StringBuilder();
        sb.append("===== Message Report =====\n");
        for (int i = 0; i < sentMessageHashes.length; i++) {
            sb.append("Message Hash: ").append(sentMessageHashes[i]).append("\n");
            sb.append("Recipient: ").append(sentRecipients[i]).append("\n");
            sb.append("Message: ").append(sentMessageTexts[i]).append("\n");
            sb.append("----------------------------\n");
        }
        return sb.toString().trim();
    }

    // ================================================================== JSON methods

    /**
     * Stores a message to a JSON file (messages.json) using manual JSON construction.
     * Called automatically when a message is stored (choice 3 in sentMessage()).
     *
     * JSON storage research reference: https://github.com/fangyidong/json-simple
     * Manual construction used to avoid external library dependency.
     */
    public static void storeMessageToJSON(Message message) {
        String json = "{"
            + "\"messageID\":\""   + message.messageID + "\","
            + "\"messageHash\":\"" + message.messageHash + "\","
            + "\"recipient\":\""   + message.recipient + "\","
            + "\"message\":\""     + message.messageText.replace("\"", "\\\"") + "\","
            + "\"status\":\""      + message.status + "\""
            + "}";

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(json + "\n");
            file.flush();
        } catch (IOException e) {
            System.out.println("Error saving to JSON: " + e.getMessage());
        }
    }

    /**
     * Reads stored messages from messages.json into the storedMessages list.
     * Uses manual JSON parsing (no external library).
     *
     * JSON reading approach reference:
     * https://stackoverflow.com/questions/2591098/how-to-parse-json-in-java
     *
     * Each line in messages.json is one JSON object written by storeMessageToJSON().
     */
    public static void loadStoredMessagesFromJSON() {
        storedMessages.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("messages.json"))) {
            String line;
            int lineNum = 0;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Extract fields using simple substring parsing
                String msgID   = extractJsonValue(line, "messageID");
                String msgHash = extractJsonValue(line, "messageHash");
                String recip   = extractJsonValue(line, "recipient");
                String text    = extractJsonValue(line, "message");
                String status  = extractJsonValue(line, "status");

                // Reconstruct a Message object from JSON data
                Message m = new Message(lineNum, recip, text);
                m.messageID   = msgID;
                m.messageHash = msgHash;
                m.status      = status;
                storedMessages.add(m);
                lineNum++;
            }
            System.out.println("Stored messages loaded from JSON (" + storedMessages.size() + " records).");
        } catch (IOException e) {
            System.out.println("No stored messages file found or error reading: " + e.getMessage());
        }
    }

    /**
     * Helper: extracts a JSON string value for a given key from a single-line JSON string.
     * Handles the simple flat JSON format written by storeMessageToJSON().
     * @param json the raw JSON line
     * @param key  the field name to look up
     * @return the string value, or "" if not found
     */
    private static String extractJsonValue(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start == -1) return "";
        start += search.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return "";
        return json.substring(start, end).replace("\\\"", "\"");
    }

    // ================================================================== reset (for tests)

    /**
     * Resets all static state. Used between unit tests to prevent contamination.
     */
    public static void resetMessages() {
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        totalMessagesSent = 0;
        sentMessageHashes = new String[0];
        sentMessageIDs    = new String[0];
        sentRecipients    = new String[0];
        sentMessageTexts  = new String[0];
    }

    // ================================================================== getters

    public String getMessageID()          { return messageID; }
    public String getMessageHash()        { return messageHash; }
    public String getRecipient()          { return recipient; }
    public String getMessageText()        { return messageText; }
    public int    getMessageNumber()      { return messageNumber; }
    public String getStatus()             { return status; }

    public static List<Message> getSentMessages()       { return sentMessages; }
    public static List<Message> getStoredMessages()     { return storedMessages; }
    public static List<Message> getDisregardedMessages(){ return disregardedMessages; }
    public static String[]      getSentMessageHashes()  { return sentMessageHashes; }
    public static String[]      getSentMessageIDs()     { return sentMessageIDs; }
    public static String[]      getSentRecipients()     { return sentRecipients; }
    public static String[]      getSentMessageTexts()   { return sentMessageTexts; }
}
