import java.util.Scanner;

/**
 * QuickChat — Main application entry point.
 * Parts 1 & 2 : Registration, login, and messaging (send / store / disregard).
 * Part  3      : Fourth menu option — "Stored Messages" with sub-menu that
 *                allows the user to work with all parallel arrays.
 *
 * Arrays managed by Message class (Part 3):
 *   sentMessageHashes  — all sent message hashes
 *   sentMessageIDs     — all sent message IDs
 *   sentRecipients     — all sent message recipients
 *   sentMessageTexts   — all sent message texts
 *   storedMessages     — list read in from messages.json
 */
public class QuickChat {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ---------------------------------------------------------------- Registration
        System.out.println("=== QuickChat Registration ===");

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username (max 5 chars, must contain '_'): ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter cell phone number (with international code, e.g. +27...): ");
        String cellPhone = scanner.nextLine();

        Login user = new Login(firstName, lastName, username, password, cellPhone);
        System.out.println(user.registerUser());

        if (!user.checkUserName() || !user.checkPasswordComplexity() || !user.checkCellPhoneNumber()) {
            System.out.println("Registration failed. Please restart and try again.");
            scanner.close();
            return;
        }

        // ---------------------------------------------------------------- Login
        System.out.println("\n=== QuickChat Login ===");
        System.out.print("Enter username: ");
        String loginUser = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPass = scanner.nextLine();

        System.out.println(user.returnLoginStatus(loginUser, loginPass));

        if (!user.loginUser(loginUser, loginPass)) {
            System.out.println("Login failed. Exiting.");
            scanner.close();
            return;
        }

        System.out.println("\nWelcome to QuickChat.");

        // Load stored messages from JSON into the storedMessages list (Part 3)
        Message.loadStoredMessagesFromJSON();

        System.out.print("How many messages do you want to send? ");
        int numMessages = Integer.parseInt(scanner.nextLine().trim());

        int messageCount = 0;

        // ---------------------------------------------------------------- Main menu loop
        while (true) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            System.out.print("Choose an option: ");

            int menuChoice = Integer.parseInt(scanner.nextLine().trim());

            // ------------------------------------------------------------ Option 1: Send
            if (menuChoice == 1) {
                if (messageCount >= numMessages) {
                    System.out.println("You have reached your message limit.");
                    continue;
                }

                System.out.print("Enter recipient cell number (with international code): ");
                String recipient = scanner.nextLine();

                System.out.print("Enter message (max 250 chars): ");
                String messageText = scanner.nextLine();

                Message msg = new Message(messageCount, recipient, messageText);

                System.out.println(msg.checkRecipientCell());
                System.out.println(msg.checkMessageLength());

                if (!msg.checkRecipientCell().contains("successfully") ||
                    !msg.checkMessageLength().equals("Message ready to send.")) {
                    System.out.println("Message not sent due to errors above.");
                    continue;
                }

                System.out.println("Message ID generated: " + msg.getMessageID());
                System.out.println("Message Hash: " + msg.getMessageHash());

                System.out.println("\n1) Send Message");
                System.out.println("2) Disregard Message");
                System.out.println("3) Store Message to send later");
                System.out.print("Choose: ");
                int sendChoice = Integer.parseInt(scanner.nextLine().trim());

                System.out.println(msg.sentMessage(sendChoice));

                if (sendChoice == 1) {
                    messageCount++;
                    Message.populateArrays(); // rebuild parallel arrays after each send
                    System.out.println("\n--- Message Details ---");
                    System.out.println("Message ID: "   + msg.getMessageID());
                    System.out.println("Message Hash: " + msg.getMessageHash());
                    System.out.println("Recipient: "    + msg.getRecipient());
                    System.out.println("Message: "      + msg.getMessageText());
                } else if (sendChoice == 3) {
                    // Persist stored message to JSON file (Part 3)
                    Message.storeMessageToJSON(msg);
                }

            // ------------------------------------------------------------ Option 2: Show sent
            } else if (menuChoice == 2) {
                System.out.println(Message.printMessages());

            // ------------------------------------------------------------ Option 3: Stored Messages (Part 3)
            } else if (menuChoice == 3) {
                storedMessagesMenu(scanner);

            // ------------------------------------------------------------ Option 4: Quit
            } else if (menuChoice == 4) {
                System.out.println("Total messages sent: " + Message.returnTotalMessages());
                System.out.println(Message.printMessages());
                System.out.println("Goodbye!");
                break;

            } else {
                System.out.println("Invalid option, please try again.");
            }
        }

        scanner.close();
    }

    // ======================================================================
    // Part 3 — Stored Messages sub-menu
    // ======================================================================

    /**
     * Sub-menu for the Stored Messages feature (Part 3, section 2a–f).
     * Works with the parallel arrays managed by the Message class.
     * @param scanner the shared Scanner instance
     */
    private static void storedMessagesMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Stored Messages ===");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest message");
            System.out.println("c) Search for a message by ID");
            System.out.println("d) Search messages for a particular recipient");
            System.out.println("e) Delete a message using message hash");
            System.out.println("f) Display full message report");
            System.out.println("0) Back to main menu");
            System.out.print("Choose: ");

            String choice = scanner.nextLine().trim().toLowerCase();

            switch (choice) {

                case "a": {
                    // Display sender and recipient of all stored messages
                    if (Message.getStoredMessages().isEmpty()) {
                        System.out.println("No stored messages.");
                    } else {
                        System.out.println("\n--- Stored Messages: Sender & Recipient ---");
                        for (Message m : Message.getStoredMessages()) {
                            System.out.println("Recipient: " + m.getRecipient()
                                    + " | Message: " + m.getMessageText());
                        }
                    }
                    break;
                }

                case "b": {
                    // Display the longest message (across all messages)
                    System.out.println("\nLongest message: " + Message.getLongestMessageOverall());
                    break;
                }

                case "c": {
                    // Search by message ID
                    System.out.print("Enter Message ID to search: ");
                    String searchID = scanner.nextLine().trim();
                    System.out.println(Message.searchMessageByID(searchID));
                    break;
                }

                case "d": {
                    // Search by recipient
                    System.out.print("Enter recipient number to search: ");
                    String searchRecipient = scanner.nextLine().trim();
                    System.out.println(Message.searchMessagesByRecipient(searchRecipient));
                    break;
                }

                case "e": {
                    // Delete by message hash
                    System.out.print("Enter message hash to delete: ");
                    String hash = scanner.nextLine().trim();
                    System.out.println(Message.deleteMessageByHash(hash));
                    break;
                }

                case "f": {
                    // Display full report
                    System.out.println(Message.displayMessageReport());
                    break;
                }

                case "0":
                    return;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }
}
