import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Login class.
 * All test data matches the assignment specification exactly.
 */
public class LoginTest {

    private Login validLogin;

    @BeforeEach
    public void setUp() {
        validLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    }

    // ===================== assertEquals Tests =====================

    @Test
    public void testUsernameCorrectlyFormatted() {
        // Test Data: "kyl_1" — has underscore, 5 chars or fewer
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
            "Username successfully captured. Password successfully captured. Cell phone number successfully added.",
            login.registerUser()
        );
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        // Test Data: "kyle!!!!!!!" — no underscore and too long
        Login login = new Login("Kyle", "Smith", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
            "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
            login.registerUser()
        );
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        // Test Data: "Ch&&sec@ke99!"
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
            "Username successfully captured. Password successfully captured. Cell phone number successfully added.",
            login.registerUser()
        );
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        // Test Data: "password" — no uppercase, number, or special char
        Login login = new Login("Kyle", "Smith", "kyl_1", "password", "+27838968976");
        assertEquals(
            "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
            login.registerUser()
        );
    }

    @Test
    public void testCellPhoneCorrectlyFormatted() {
        // Test Data: +27838968976
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
            "Username successfully captured. Password successfully captured. Cell phone number successfully added.",
            login.registerUser()
        );
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        // Test Data: 08966553 — no international code
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "08966553");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
            login.registerUser()
        );
    }

    // ===================== assertTrue / assertFalse Tests =====================

    @Test
    public void testLoginSuccessful() {
        assertTrue(validLogin.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        assertFalse(validLogin.loginUser("wrongUser", "wrongPass"));
    }

    @Test
    public void testUsernameCorrectlyFormattedBoolean() {
        assertTrue(validLogin.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormattedBoolean() {
        Login login = new Login("Kyle", "Smith", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityBoolean() {
        assertTrue(validLogin.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityBoolean() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "password", "+27838968976");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testCellPhoneCorrectlyFormattedBoolean() {
        assertTrue(validLogin.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrectlyFormattedBoolean() {
        Login login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "08966553");
        assertFalse(login.checkCellPhoneNumber());
    }
}
