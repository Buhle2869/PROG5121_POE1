import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Task class - Part 3.
 * Covers task description validation, task ID generation,
 * adding tasks, searching, deleting, total hours, and report display.
 *
 * Test data mirrors the QuickChat assignment specification:
 *   Task 0: "Create Login",    "Mike Smith",   5 hrs, "To Do"
 *   Task 1: "Create Add Features", "Edward Harrison", 8 hrs, "Doing"
 *   Task 2: "Create Reports",  "Samantha Paulson", 2 hrs, "Done"
 *   Task 3: "Add Arrays",      "Glenda Oberholzer", 11 hrs, "To Do"
 */
public class TaskTest {

    private Task task0;
    private Task task1;
    private Task task2;
    private Task task3;

    @BeforeEach
    public void setUp() {
        // Reset static state before every test to prevent cross-test contamination
        Task.resetTasks();

        task0 = new Task("Create Login",
                         "Create Login to allow access",
                         "Mike Smith",
                         5,
                         "To Do");

        task1 = new Task("Create Add Features",
                         "Create Add features for messages",
                         "Edward Harrison",
                         8,
                         "Doing");

        task2 = new Task("Create Reports",
                         "Create Reports for tasks",
                         "Samantha Paulson",
                         2,
                         "Done");

        task3 = new Task("Add Arrays",
                         "Create the arraylists needed",
                         "Glenda Oberholzer",
                         11,
                         "To Do");
    }

    // ==================== Task Description Tests ====================

    @Test
    public void testTaskDescriptionUnder50Characters() {
        // "Create Login to allow access" = 28 chars — valid
        assertEquals("Task successfully captured.", task0.checkTaskDescription());
    }

    @Test
    public void testTaskDescriptionOver50Characters() {
        Task longDesc = new Task(
                "Test Task",
                "This description is deliberately over fifty characters long to trigger the error message",
                "Mike Smith",
                3,
                "To Do");
        assertEquals(
                "Please enter a task description of less than 50 characters.",
                longDesc.checkTaskDescription());
    }

    @Test
    public void testTaskDescriptionExactly50Characters() {
        // Boundary: exactly 50 chars should pass
        String exactly50 = "A".repeat(50);
        Task t = new Task("Test Task", exactly50, "Mike Smith", 1, "To Do");
        assertEquals("Task successfully captured.", t.checkTaskDescription());
    }

    @Test
    public void testTaskDescriptionExactly51Characters() {
        // One over the limit should fail
        String fiftyOne = "A".repeat(51);
        Task t = new Task("Test Task", fiftyOne, "Mike Smith", 1, "To Do");
        assertEquals(
                "Please enter a task description of less than 50 characters.",
                t.checkTaskDescription());
    }

    // ==================== Task ID Tests ====================

    @Test
    public void testTaskIDCorrectlyFormattedForTask0() {
        // taskName="Create Login" -> first 2 = "CR", taskNumber=0,
        // developerDetails="Mike Smith" -> last 2 = "TH"
        // Expected: "CR:0:TH"
        assertEquals("CR:0:TH", task0.getTaskID());
    }

    @Test
    public void testTaskIDCorrectlyFormattedForTask1() {
        // taskName="Create Add Features" -> first 2 = "CR", taskNumber=1,
        // developerDetails="Edward Harrison" -> last 2 = "ON"
        // Expected: "CR:1:ON"
        assertEquals("CR:1:ON", task1.getTaskID());
    }

    @Test
    public void testTaskIDCorrectlyFormattedForTask2() {
        // taskName="Create Reports" -> first 2 = "CR", taskNumber=2,
        // developerDetails="Samantha Paulson" -> last 2 = "ON"
        // Expected: "CR:2:ON"
        assertEquals("CR:2:ON", task2.getTaskID());
    }

    @Test
    public void testTaskIDCorrectlyFormattedForTask3() {
        // taskName="Add Arrays" -> first 2 = "AD", taskNumber=3,
        // developerDetails="Glenda Oberholzer" -> last 2 = "ER"
        // Expected: "AD:3:ER"
        assertEquals("AD:3:ER", task3.getTaskID());
    }

    @Test
    public void testTaskIDIsUpperCase() {
        String id = task0.getTaskID();
        assertEquals(id.toUpperCase(), id, "Task ID should be all uppercase");
    }

    @Test
    public void testTaskIDContainsColonSeparators() {
        String id = task0.getTaskID();
        assertTrue(id.contains(":"), "Task ID should contain colon separators");
        assertEquals(2, id.chars().filter(c -> c == ':').count(),
                "Task ID should contain exactly 2 colons");
    }

    // ==================== Task Number Tests ====================

    @Test
    public void testTaskNumbersAreSequential() {
        assertEquals(0, task0.getTaskNumber());
        assertEquals(1, task1.getTaskNumber());
        assertEquals(2, task2.getTaskNumber());
        assertEquals(3, task3.getTaskNumber());
    }

    // ==================== Add Task / Total Hours Tests ====================

    @Test
    public void testAddTaskReturnsSuccessMessage() {
        assertEquals("Task successfully added.", task0.addTask());
    }

    @Test
    public void testReturnTotalHoursForAllTasks() {
        // 5 + 8 + 2 + 11 = 26
        task0.addTask();
        task1.addTask();
        task2.addTask();
        task3.addTask();
        assertEquals(26, Task.returnTotalHours(),
                "Total hours across all tasks should be 26");
    }

    @Test
    public void testReturnTotalHoursWithNoTasks() {
        // No tasks added — should be 0
        assertEquals(0, Task.returnTotalHours());
    }

    @Test
    public void testReturnTotalHoursWithSingleTask() {
        task0.addTask(); // 5 hrs
        assertEquals(5, Task.returnTotalHours());
    }

    // ==================== Search Tests ====================

    @Test
    public void testSearchTaskByNameFound() {
        task0.addTask();
        task1.addTask();
        String result = Task.searchTaskByName("Create Login");
        assertTrue(result.contains("Create Login"),
                "Search result should contain the task name");
        assertTrue(result.contains("Mike Smith"),
                "Search result should contain the developer name");
    }

    @Test
    public void testSearchTaskByNameNotFound() {
        task0.addTask();
        assertEquals("Task not found.", Task.searchTaskByName("Nonexistent Task"));
    }

    @Test
    public void testSearchTaskByNameCaseInsensitive() {
        task0.addTask();
        String result = Task.searchTaskByName("create login");
        assertTrue(result.contains("Create Login"),
                "Search should be case-insensitive");
    }

    @Test
    public void testSearchTasksByDeveloperFound() {
        task0.addTask();
        task1.addTask();
        String result = Task.searchTasksByDeveloper("Mike Smith");
        assertTrue(result.contains("Mike Smith"),
                "Search result should contain the developer name");
        assertTrue(result.contains("Create Login"),
                "Search result should contain Mike Smith's task");
    }

    @Test
    public void testSearchTasksByDeveloperNotFound() {
        task0.addTask();
        assertEquals("No tasks found for developer.",
                Task.searchTasksByDeveloper("Unknown Developer"));
    }

    // ==================== Delete Task Tests ====================

    @Test
    public void testDeleteTaskByNameSuccessfully() {
        task0.addTask();
        String result = Task.deleteTask("Create Login");
        assertEquals("Entry \"Create Login\" successfully deleted.", result);
    }

    @Test
    public void testDeleteTaskRemovedFromList() {
        task0.addTask();
        task1.addTask();
        Task.deleteTask("Create Login");
        assertEquals("Task not found.", Task.searchTaskByName("Create Login"),
                "Deleted task should no longer be found");
    }

    @Test
    public void testDeleteTaskNotFound() {
        task0.addTask();
        assertEquals("Task not found.", Task.deleteTask("Ghost Task"));
    }

    @Test
    public void testDeleteTaskReducesTotalHours() {
        task0.addTask(); // 5 hrs
        task1.addTask(); // 8 hrs
        Task.deleteTask("Create Login");
        assertEquals(8, Task.returnTotalHours(),
                "Total hours should decrease after deletion");
    }

    // ==================== Display Report Tests ====================

    @Test
    public void testDisplayReportContainsDoneTask() {
        task0.addTask();
        task1.addTask();
        task2.addTask();
        task3.addTask();
        String report = Task.displayReport();
        // Task with "Done" status should appear
        assertTrue(report.contains("Done"),
                "Report should contain a task with status 'Done'");
    }

    @Test
    public void testDisplayReportListsDeveloperAndTask() {
        task0.addTask();
        String report = Task.displayReport();
        assertTrue(report.contains("Mike Smith"), "Report should list the developer");
        assertTrue(report.contains("Create Login"), "Report should list the task name");
    }

    @Test
    public void testDisplayReportWithNoTasks() {
        assertEquals("No tasks available.", Task.displayReport());
    }

    @Test
    public void testDisplayReportContainsAllTasks() {
        task0.addTask();
        task1.addTask();
        task2.addTask();
        task3.addTask();
        String report = Task.displayReport();
        assertTrue(report.contains("Create Login"),       "Report should contain task 0");
        assertTrue(report.contains("Create Add Features"),"Report should contain task 1");
        assertTrue(report.contains("Create Reports"),     "Report should contain task 2");
        assertTrue(report.contains("Add Arrays"),         "Report should contain task 3");
    }

    // ==================== Print Task Details Tests ====================

    @Test
    public void testPrintTaskDetailsContainsAllFields() {
        String details = task0.printTaskDetails();
        assertTrue(details.contains("Create Login"),          "Details should include task name");
        assertTrue(details.contains("Mike Smith"),            "Details should include developer");
        assertTrue(details.contains("To Do"),                 "Details should include status");
        assertTrue(details.contains("5"),                     "Details should include duration");
        assertTrue(details.contains(task0.getTaskID()),       "Details should include task ID");
    }

    @Test
    public void testPrintTaskDetailsContainsTaskNumber() {
        String details = task1.printTaskDetails();
        assertTrue(details.contains(String.valueOf(task1.getTaskNumber())),
                "Details should contain the task number");
    }

    // ==================== Status Validation Tests ====================

    @Test
    public void testTaskStatusToDoIsStoredCorrectly() {
        assertEquals("To Do", task0.getTaskStatus());
    }

    @Test
    public void testTaskStatusDoingIsStoredCorrectly() {
        assertEquals("Doing", task1.getTaskStatus());
    }

    @Test
    public void testTaskStatusDoneIsStoredCorrectly() {
        assertEquals("Done", task2.getTaskStatus());
    }
}
